
#ifndef __UART_H
#define __UART_H

// Application interface to hardware

void PrintByte(char c);


#endif /* __UART_H */