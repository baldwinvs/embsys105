N. Strathy, March 2019

STEPS TO ADD INTERRUPT DRIVEN TOUCH TO YOUR MP3PLAYER.

SPOILER: requires some soldering.

We want to connect the IRQ signal output by the:

	Adafruit 2.8" TFT Touch Shield w/ Cap Touch

to an available GPIO on the

	Nucleo-F401RE

1. 	Determine which pinout from the touch panel is the interrupt (IRQ):
		According to the Adafruit document:
			Solder jumper "TS Int" to jumper #7 to access the interrupt signal on pin D7 (PA8 Nucleo)
			PROBLEM: 
				CONFLICT!: Adafruit Music Maker Shield uses D7 for MCS (Command interface chip select)!
				Notice that:
					We can solder a wire from jumper #7 to jumper #5: good news!: D5/PB4 is not already in use.
					So we can take the output from the touch panel on D5 as input to PB4

2.	As determined above, solder a small length of wire (0.5") from jumper "TS int" to jumper #5.

3.	Add the following files to your project under BSP\ST\StdPeripheralDrivers:

		stm32f4xx_exti.c
		stm32f4xx_exti.h
		stm32f4xx_syscfg.c
		stm32f4xx_syscfg.h

4. 	Add these lines to BSP\nucleoboard.h:

		#include "stm32f4xx_syscfg.h"
		#include "stm32f4xx_exti.h"

	
5. 	Configure GPIO PB4 to take the touch IRQ signal as input:

		RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB, ENABLE);
		GPIO_InitTypeDef GPIO_InitStruct;
		GPIO_InitStruct.GPIO_Pin = GPIO_Pin_4; // PB4/D5 
		GPIO_InitStruct.GPIO_Mode = GPIO_Mode_IN;
		GPIO_InitStruct.GPIO_Speed = GPIO_Speed_2MHz;
		GPIO_InitStruct.GPIO_OType = GPIO_OType_OD;
		GPIO_InitStruct.GPIO_PuPd = GPIO_PuPd_NOPULL;
		GPIO_Init(GPIOB, &GPIO_InitStruct);

6. 	Configure PB4 as an external interrupt:

        EXTI_InitTypeDef EXTI_InitStruct;
        EXTI_InitStruct.EXTI_Line = EXTI_Line4;
        EXTI_InitStruct.EXTI_Mode = EXTI_Mode_Interrupt;
        EXTI_InitStruct.EXTI_Trigger = EXTI_Trigger_Falling;
        EXTI_InitStruct.EXTI_LineCmd = ENABLE;
        EXTI_Init(&EXTI_InitStruct);
        
        SYSCFG_EXTILineConfig(EXTI_PortSourceGPIOB, 4);
        
        NVIC_EnableIRQ(EXTI4_IRQn);
		
7.	Add an interrupt handler to Micrium\Software\uCOS-II\ARM-Cortex-M4\IAR\os_cpu_c.c

		#include  <stm32f4xx.h>
		#include "stm32f4xx_exti.h"

		void GetTouchPoint();

void EXTI4IrqHandler(void)
{
    OS_CPU_SR  cpu_sr;

    OS_ENTER_CRITICAL();
    OSIntNesting++;
    
    EXTI_ClearITPendingBit(EXTI_Line4);
    NVIC_ClearPendingIRQ(EXTI4_IRQn);
    
    GetTouchPoint();
    
    OS_EXIT_CRITICAL();    

    OSIntExit();         /* Tell uC/OS-II that we are leaving the ISR            */
}

8. 	Add a line to Micrium\Software\uCOS-II\ARM-Cortex-M4\IAR\os_cpu_c.h

		void  EXTI4IrqHandler         (void);
			
9. 	Modify the corresponding IRQ handler in BSP\startup.s:

	    EXTERN  EXTI4IrqHandler
			...
		DCD     EXTI4IrqHandler               ; EXTI Line4 Touch IRQ handler
			...
		Remove      PUBWEAK  EXTI4IrqHandler 
			...
		Remove      EXTI4IrqHandler from the list appearing above UnusedIrqHandler
		
10. In Adafruit\Adafruit_FT6206\Adafruit_FT6206.cpp:
		
		in boolean Adafruit_FT6206::begin(uint8_t threshhold): add:

			writeRegister8(FT6206_REG_G_MODE, 0); // Set interrupt mode on touch controller

11.	In App\tasks.c:

	Add a function to get the current touch point and post it to the touch task:

		void GetTouchPoint()
		{
		  static TS_Point rawPoint;
			rawPoint = touchCtrl.getPoint();
			OSMboxPost(touchMbox, &rawPoint);
		}

		Instead of polling the touch panel:
			Pend on the touchMbox and when a point arrives process it as before

END